<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Phone</th>
            <th scope="col">Gender</th>
            <th scope="col">Image</th>
            <th scope="col">File</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th scope="row"><?php echo e($i + 1); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone); ?></td>
                <td><?php echo e(ucfirst($user->gender)); ?></td>
                <td>
                    <img src='<?php echo e(asset('storage/' . $user->image)); ?>' alt='<?php echo e($user->name); ?>' width='100px'>
                </td>
                <td>
                    <?php if(!empty($user->file)): ?>
                        <a href="<?php echo e(asset('storage/' . $user->file)); ?>" download>Download</a>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary edit-user" data-id="<?php echo e($user->id); ?>">Edit</button>
                    <button class="btn btn-sm btn-danger delete-user" data-id="<?php echo e($user->id); ?>">Delete</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8">data not found</td>
            </tr>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="8">
                <?php echo e($users->links()); ?>

            </td>
        </tr>
    </tfoot>
</table>
<?php /**PATH /mnt/sdb5/web/examples/laravel-crud/resources/views/users/list.blade.php ENDPATH**/ ?>