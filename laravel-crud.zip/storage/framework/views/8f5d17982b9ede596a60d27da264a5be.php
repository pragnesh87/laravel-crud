<form method="post" action="" enctype="multipart/form-data" id="create-user-form">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" />
        <?php if($errors->has('name')): ?>
            <span class="error"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email">
        <?php if($errors->has('email')): ?>
            <span class="error"><?php echo e($errors->first('email')); ?></span>
        <?php endif; ?>
    </div>
    <div class="mb-3">
        <label for="phone" class="form-label">Phone</label>
        <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" name="phone">
        <?php if($errors->has('phone')): ?>
            <span class="error"><?php echo e($errors->first('phone')); ?></span>
        <?php endif; ?>
    </div>
    <fieldset>
        <legend>Gender</legend>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="gender" id="gender_male" value="male">
            <label class="form-check-label" for="gender_male">
                Male
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="gender" id="gender_female" value="female">
            <label class="form-check-label" for="gender_female">
                Female
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="gender" id="gender_other" value="other">
            <label class="form-check-label" for="gender_other">
                Other
            </label>
        </div>
        <?php if($errors->has('gender')): ?>
            <span class="error"><?php echo e($errors->first('gender')); ?></span>
        <?php endif; ?>
    </fieldset>

    <div class="mb-3">
        <label for="image" class="form-label">Image</label>
        <input type="file" class="form-control" name="image" id="image" accept="image/*">
        <?php if($errors->has('image')): ?>
            <span class="error"><?php echo e($errors->first('image')); ?></span>
        <?php endif; ?>
    </div>
    <div class="mb-3">
        <label for="file" class="form-label">File</label>
        <input type="file" class="form-control" id="file" name="file">
        <?php if($errors->has('file')): ?>
            <span class="error"><?php echo e($errors->first('file')); ?></span>
        <?php endif; ?>
    </div>
    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="terms"
            id="terms">
        <label class="form-check-label" for="terms">Accept terms and condition</label>
        <?php if($errors->has('terms')): ?>
            <span class="error"><?php echo e($errors->first('terms')); ?></span>
        <?php endif; ?>
    </div>
</form>
<?php /**PATH /mnt/sdb5/web/examples/laravel-crud/resources/views/users/create.blade.php ENDPATH**/ ?>