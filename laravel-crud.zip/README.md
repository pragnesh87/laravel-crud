# Larave CRUD

> Step to run application

-   composer install
-   npm install
-   configure database in .env file
-   php artisan migrate
-   php artisan storage:link
-   npm run dev
-   php artisan serve
